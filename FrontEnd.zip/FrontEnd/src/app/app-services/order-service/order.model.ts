export class Order {
    _id: string;
    customerID: String;
    totalPrice: number;
    orderDate: String;
    status:String;
    paymentOption: String;
    discountCode: Number;
    feeShip:number;
}
