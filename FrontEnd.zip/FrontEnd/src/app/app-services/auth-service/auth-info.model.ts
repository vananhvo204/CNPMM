export interface AuthInfo {
    // TODO: Add other info later
    isLoggedIn: boolean;
    role: string;
    account: Object;
  }