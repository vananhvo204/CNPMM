export class Seri {
    _id: String;
    seriName: String;
}
