export class Customer {
    _id: string;
    userID: string;
    name: string;
    phone: string;
    address: string;
    email: string;
    latitude: number;
    longitude: number;
    feeShip:number;
    // city: string;
    // districts: string;
    // wards: string;
    typeAddress: string;
}
