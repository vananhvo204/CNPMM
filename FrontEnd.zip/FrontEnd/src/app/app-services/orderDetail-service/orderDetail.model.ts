
export class OrderDetail {
    _id: string;
    orderID: String;
    cakeID: String;
    count: Number;
    price: Number;
    sale:Number;
}
