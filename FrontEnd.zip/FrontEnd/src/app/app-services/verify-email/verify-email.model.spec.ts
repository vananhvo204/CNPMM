import { VerifyEmail } from './verify-email.model';

describe('VerifyEmail', () => {
  it('should create an instance', () => {
    expect(new VerifyEmail()).toBeTruthy();
  });
});
