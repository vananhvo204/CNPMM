export class VerifyEmail {
    success: boolean;
    info: string;
}
