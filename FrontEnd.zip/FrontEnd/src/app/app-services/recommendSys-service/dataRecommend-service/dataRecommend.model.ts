export class datasetRecommend {
    _id:string;
    cakeID:string;
    userID: string;
    rate: Number;
    buy: Number;
    click:Number;
}
