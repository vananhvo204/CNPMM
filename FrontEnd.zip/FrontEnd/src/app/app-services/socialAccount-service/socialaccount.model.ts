export class SocialAccount {
    _id: string;
    email: string;
    username: string;
    imageUrl: string;
    facebook_id: string;
    google_id: string;
    role: String;
}
