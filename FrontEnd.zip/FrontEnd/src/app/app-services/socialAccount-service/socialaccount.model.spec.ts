import { SocialAccount } from "./socialaccount.model";

describe('Socialaccount', () => {
  it('should create an instance', () => {
    expect(new SocialAccount()).toBeTruthy();
  });
});
