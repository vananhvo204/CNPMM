export class Point {
    _id:string;
    userID: string;
    point: Number;
  
}
