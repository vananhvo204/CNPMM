export class Location {
    _id: string;
    city: String;
    districs: String;
    wards: String;

}
