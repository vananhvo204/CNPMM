
export class CartCake {
    _id: string;
    userID: String;
    cakeID: String;
    count: Number;
}
