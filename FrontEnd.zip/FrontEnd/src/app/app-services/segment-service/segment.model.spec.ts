import { Segment } from './segment.model';

describe('Segment', () => {
  it('should create an instance', () => {
    expect(new Segment()).toBeTruthy();
  });
});
