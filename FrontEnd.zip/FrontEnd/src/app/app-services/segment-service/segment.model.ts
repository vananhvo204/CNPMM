export class Segment {
    _id: String;
    nameWheel: String;
    segments: [];
    isActive: Boolean;
}
