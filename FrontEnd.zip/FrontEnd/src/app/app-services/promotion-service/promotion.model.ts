export class Promotion {
    _id:string;
    headerPromotion:string;
    imgPromotion:string;
    detailPromotion: string;
    discount: number;
    ifDiscount: number;
    startDate: string;
    endDate: string;
    listBookIn: Object;
    isShow: string;
    StatusUpdateBookSale:string;
}
