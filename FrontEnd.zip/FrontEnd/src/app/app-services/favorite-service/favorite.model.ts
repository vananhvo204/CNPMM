export class Favorite {
    _id: string;
    userID: string;
    cakeID: string;
}
