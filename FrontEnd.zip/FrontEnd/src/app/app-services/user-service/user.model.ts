export class User {
    _id:string;
    email: string;
    username: string;
    password: string;
    role: string;
    imageUrl: string;
    status: boolean;
}
