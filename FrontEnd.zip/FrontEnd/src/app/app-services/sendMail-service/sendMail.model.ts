export class SendMail{
   name:String;
   imgCake: String;
   count: String;
   price:String;
   email:String;
   totalPrice:String;
   nameCake : String;
   address : String;
   phone: String;
   orderDate: String;
   paymentOption: String;
   discountCode:Number;
   feeShip:Number;
   sale:String;
}