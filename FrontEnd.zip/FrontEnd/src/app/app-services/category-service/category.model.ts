export class Category {
    _id: String;
    nameCategory: String;
    imgCategory: String;
    detailCategory: String;
}
