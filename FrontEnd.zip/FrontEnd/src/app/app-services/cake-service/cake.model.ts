export class Cake {
     _id: string;
     nameCake: string;
     categoryID: string;     
     priceCake: number;
     detailCake: string;
     imgCake: string;
     sale: number;
     count: number;
     quantity:Number;
     rate:Object;
}
