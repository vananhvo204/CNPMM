export class CakeFiter{
    category_id: string;
    price1: number;
    price2: number;
    nameCake: string;
    sortByPrice: string;
}