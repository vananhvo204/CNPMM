import { Cake } from './cake.model';

describe('Cake', () => {
  it('should create an instance', () => {
    expect(new Cake()).toBeTruthy();
  });
});
