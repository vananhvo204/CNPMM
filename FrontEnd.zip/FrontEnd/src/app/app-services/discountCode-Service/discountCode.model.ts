export class DiscountCode {
    _id: string;
    userID: string;
    discountCode: Number;
    discountDetail: string;
    status:Number;
}
