export class Rating {
    _id:string;
    cakeID:string;
    userID: string;
    star: string;
    review: string;
}
